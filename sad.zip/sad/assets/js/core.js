$(document).ready(function() {
    $("#cvvbtn").click(function() {
        $("#cvvdiv").slideToggle();
    });
    $("#ccnbtn").click(function() {
        $("#ccndiv").slideToggle();
    });
    $("#deadbtn").click(function() {
        $("#deaddiv").slideToggle();
    });
    $("#totalbtn").click(function(){
        $("totaldiv").slideToggle();
    });
});

$("#start").click(function() {
    var card = $("#card").val();
    var sec = $("#sec").val();
    var gate = $("#gw").val();
    var carda = card.split("\n");
    var cvv = 0;
    var ccn = 0;
    var dead = 0;
    var total = carda.length;
    carda.forEach(function(value, index) {
        setTimeout(function() {
            $.ajax({
                url: gate + '.php?card=' + value + '&sec=' + sec,
                type: 'GET',
                async: true,
                success: function(result) {
                    if (result.match("LIVE")) {
                        $("#cvvdiv").append(result);
                        update();
                        cvv++;
                    } else if (result.match("#CCN")) {
                        $("#ccndiv").append(result);
                        update();
                        ccn++;
                    } else {
                        $("#deaddiv").append(result);
                        update();
                        dead++;
                    }
                    $('#cvvc').html(cvv);
                    $('#ccnc').html(ccn);
                    $('#deadc').html(dead);
                    $('#totalc').html(total);
                }
            });
        }, index * 500);
    });
});
