$(document).ready(function () {
});
$("#generate").click(function () {
	document.getElementById("lista").value = gen();
});

function gen() {
	var amt = $("#amount").val();
	var ccs = [];
	for(x = 0; x < amt; x++) {
		ccs.push(generate());
	}
	return ccs.join("\n");
}
function rand(rlength) {
	var randa = [];
	while(randa.length < rlength){
	var rand = Math.floor(Math.random() * 10);
		randa.push(rand);
	}
	return randa.join('');
}

function generate() {
	var bin = $("#bin").val();
	var mon = $("#month").val();
	var yea = $("#year").val();
	var cci = bin + rand(15 - bin.length);
	var evena = [];
	var odda = [];
	for(var e = 0; e < 15; e += 2) {
		var even = cci[e] * 2;
		if(even.toString().length == 2){
			even = even.toString().split('');
			even = parseInt(even[0]) + parseInt(even[1]);
		}
	evena.push(even);
	}
	for(var o = 1; o < 15; o += 2) {
		var odd = cci[o];
		odda.push(odd);
	}
	var odds = eval(odda.join('+'));
	var evens = eval(evena.join('+'));
	var total = odds + evens;
	var csum = 10 - total.toString()[1];
	if(csum == 10){
		csum = 0;
	}
	if(yy(yea).length == 4){
	return cci + csum + '|' +mm(mon) + '|' + yy(yea) + '|' + cvv();
	}
	else { 
		return cci + csum + '|' +mm(mon) + '|202' + yy(yea) + '|' + cvv();
	}
}

function mm(mon) {
	if(mon) {
	return mon;
	}
	else {
	var mm = Math.floor(Math.random() * 12) + 1;
	if(mm.toString().length == 1){
		mm = '0' + mm;
	}
	return mm;
	}
}
function yy(yea) {
	if(yea) {
	return yea;
	}
	else {
	return Math.floor(Math.random() * 8) + 2;
	}
}

function cvv() {
	cvva = [];
	while(cvva.length < 3) {
		var cvv = Math.floor(Math.random() * 10);
		cvva.push(cvv);
	}
	return cvva.join('');
}